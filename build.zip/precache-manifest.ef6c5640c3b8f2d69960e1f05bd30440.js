self.__precacheManifest = [
  {
    "revision": "1b065de36acdcd3118b5ea3707b9cf8b",
    "url": "./static/media/ac_head_bg.1b065de3.png"
  },
  {
    "revision": "0878ca02be6924e7534d",
    "url": "./static/css/main.8a445480.chunk.css"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.8c97409f.js"
  },
  {
    "revision": "3eeccaa6b1932f384e4b",
    "url": "./static/js/2.3eeccaa6.chunk.js"
  },
  {
    "revision": "240deac726be3e384d0df4b59b8fd0a3",
    "url": "./static/media/head_wrap.240deac7.jpg"
  },
  {
    "revision": "cc5382bd4a3d051813bdc0051ced075d",
    "url": "./static/media/con2.cc5382bd.jpg"
  },
  {
    "revision": "dcb04a03dc4c54decd620f875fccb520",
    "url": "./static/media/con1.dcb04a03.jpg"
  },
  {
    "revision": "2b49b65cf24731d8f0e0de457699b974",
    "url": "./static/media/head_con.2b49b65c.jpg"
  },
  {
    "revision": "eefc31f1268586a8e2bb2bf704ee76de",
    "url": "./static/media/maoyao.eefc31f1.jpg"
  },
  {
    "revision": "819a194bdc0636cb19114c05a4d34d9f",
    "url": "./static/media/xiaolv.819a194b.jpg"
  },
  {
    "revision": "8a612b90a196c8f3ba013700863b9441",
    "url": "./static/media/ac_body_bg.8a612b90.png"
  },
  {
    "revision": "445c40f17d0fdf2f8162131d6adab6d0",
    "url": "./static/media/in_sprite.445c40f1.png"
  },
  {
    "revision": "bf1b291b5531d50fd26b47df1eb3615c",
    "url": "./static/media/ac_global.bf1b291b.png"
  },
  {
    "revision": "0878ca02be6924e7534d",
    "url": "./static/js/main.0878ca02.chunk.js"
  },
  {
    "revision": "b0a83e39ce70675752ce57b3e758ce0d",
    "url": "./static/media/in-animate-egg.b0a83e39.png"
  },
  {
    "revision": "8d824c6636d9d3b5edb84410d973245c",
    "url": "./static/media/ac_vip_icon.8d824c66.png"
  },
  {
    "revision": "135fb0aff28cdb255f18ec2176b9dae2",
    "url": "./static/media/gamble_bg.135fb0af.png"
  },
  {
    "revision": "ba38959548ac5993bb27966aee84cce4",
    "url": "./static/media/japan_all.ba389595.png"
  },
  {
    "revision": "999a55ab5a5eb72a2e5e49d34d3e6600",
    "url": "./static/media/page_works_sprite.999a55ab.png"
  },
  {
    "revision": "59f994fc38b2fa01e9808400ce57fadc",
    "url": "./static/media/ac.all_money.59f994fc.png"
  },
  {
    "revision": "c0314334cb83f0051a375ba455b198a8",
    "url": "./static/media/ac_comment_sprite_v1.2.1.c0314334.png"
  },
  {
    "revision": "b354cba4563cf3be933d74dda8ee1cfb",
    "url": "./static/media/home_bg.b354cba4.jpg"
  },
  {
    "revision": "fc9fa43f12b5514e0612d05a1be37972",
    "url": "./static/media/home_night_bg.fc9fa43f.jpg"
  },
  {
    "revision": "db3d06d5a5d2186251b1df55c8430e69",
    "url": "./static/media/buy_sprite.db3d06d5.gif"
  },
  {
    "revision": "7628cc83df8fa503bce0f5e5e58512b0",
    "url": "./static/media/h_sprite.7628cc83.gif"
  },
  {
    "revision": "b68027663f6135b19b3c737347739f14",
    "url": "./static/media/png_sprite.b6802766.png"
  },
  {
    "revision": "e37b07dff49320e5022e4e4c08151b1f",
    "url": "./index.html"
  }
];